<?php namespace App\Controllers;
use CI4\controllers;
use App\Models\MCruddata;

class Cruddata extends BaseController
{
    public function index()
    {
        $model = new MCruddata();
        $data['tb_me'] = $model-> getMe();
        $data['content'] = 'cruddata/index_cruddata';
        $data['title'] = 'ini halaman crud';
        return view('template/index_body', $data);
    }
}
?>