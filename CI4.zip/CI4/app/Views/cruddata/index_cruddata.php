<h2>Bordered Table</h2>
  <p>The .table-bordered class adds borders to a table:</p>            
  <table class="table">
    <thead>
      <tr>
        <th>id</th>
        <th>detail</th>
      </tr>
    </thead>
    <tbody>
        <?php
         $am= 0;
         foreach ($tb_me as $key){
         $am++;
         
        ?>
      <tr>
        <td><?php echo $key['am_id'] ?></td>
        <td><?php echo $key['am_detail'] ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>