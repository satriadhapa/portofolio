<?php namespace App\Models; 
use CI4\Model;

class MCruddata extends Models
{
    protected $table = 'tb_me';
    public function getMe($id = false)
    {
        if($id === false){
            return $this -> findAll();
        } else {
            return $this ->getWhere(['am_id' => $id]);
        }
    }
}
?>